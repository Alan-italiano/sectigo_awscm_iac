"""
useful links
https://certbot.eff.org/docs/_modules/certbot/ocsp.html
https://stackoverflow.com/a/64505318/4791963
"""

import base64
import ssl
import requests
from urllib.parse import urljoin
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.x509 import ocsp
from cryptography.x509.oid import ExtensionOID, AuthorityInformationAccessOID


class OSCPError(Exception):
    pass


def get_cert_for_hostname(hostname, port):
    ssl.create_default_context()
    conn = ssl.create_connection((hostname, port))
    context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
    sock = context.wrap_socket(conn, server_hostname=hostname)
    cert_der = sock.getpeercert(True)
    cert_pem = ssl.DER_cert_to_PEM_cert(cert_der)
    return x509.load_pem_x509_certificate(cert_pem.encode('ascii'), default_backend())


def get_issuer(cert):
    aia = cert.extensions.get_extension_for_oid(ExtensionOID.AUTHORITY_INFORMATION_ACCESS).value
    issuers = [ia for ia in aia if ia.access_method == AuthorityInformationAccessOID.CA_ISSUERS]
    if not issuers:
        raise OSCPError(f'no issuers entry in AIA')
    return issuers[0].access_location.value


def get_ocsp_server(cert):
    aia = cert.extensions.get_extension_for_oid(ExtensionOID.AUTHORITY_INFORMATION_ACCESS).value
    ocsps = [ia for ia in aia if ia.access_method == AuthorityInformationAccessOID.OCSP]
    if not ocsps:
        raise OSCPError(f'no ocsp server entry in AIA')
    return ocsps[0].access_location.value


def get_issuer_cert(ca_issuer):
    issuer_response = requests.get(ca_issuer)
    if issuer_response.ok:
        issuer_der = issuer_response.content
        issuer_pem = ssl.DER_cert_to_PEM_cert(issuer_der)
        return x509.load_pem_x509_certificate(issuer_pem.encode('ascii'), default_backend())
    raise OSCPError(f'fetching issuer cert  failed with response status: {issuer_response.status_code}')


def get_oscp_request(ocsp_server, cert, issuer_cert):
    builder = ocsp.OCSPRequestBuilder()
    builder = builder.add_certificate(cert, issuer_cert, SHA256())
    req = builder.build()
    req_path = base64.b64encode(req.public_bytes(serialization.Encoding.DER))
    return urljoin(ocsp_server + '/', req_path.decode('ascii'))


def get_ocsp_cert_status(ocsp_server, cert, issuer_cert):

    builder = ocsp.OCSPRequestBuilder()
    builder = builder.add_certificate(cert, issuer_cert, SHA256())
    request = builder.build()
    request_binary = request.public_bytes(serialization.Encoding.DER)
    response = requests.post(ocsp_server, data=request_binary,
                             headers={'Content-Type': 'application/ocsp-request'})
    response.raise_for_status()
    response_ocsp = ocsp.load_der_ocsp_response(response.content)
    return response_ocsp.certificate_status.name


def get_cert_status_for_host(hostname, port):
    cert = get_cert_for_hostname(hostname, port)
    ca_issuer = get_issuer(cert)
    issuer_cert = get_issuer_cert(ca_issuer)
    ocsp_server = get_ocsp_server(cert)
    return get_ocsp_cert_status(ocsp_server, cert, issuer_cert)


def get_ocsp_status_of_cert(cert_pem: str) -> str:
    server_cert = x509.load_pem_x509_certificate(cert_pem.encode('ascii'), default_backend())
    ocsp_server = get_ocsp_server(server_cert)
    ca_issuer = get_issuer(server_cert)
    issuer_cert = get_issuer_cert(ca_issuer)
    status = get_ocsp_cert_status(ocsp_server, server_cert, issuer_cert)
    return status


