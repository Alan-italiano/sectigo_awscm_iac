import os
import certbot.main
import logging
from configprovider import ConfigProvider as config
import multiprocessing

class CertbotProvider:
    def certbot_get_cert(self, account, domains, account_id):
        try:
            certbot.main.main([
                'certonly',  # Obtain a cert but don't install it
                '--standalone',
                '--noninteractive',  # Run in non-interactive mode
                '--agree-tos',  # Agree to the terms of service,
                '--email', account[0]['email'],  # Email
                '--server', account[0]['acme-endpoint'],  # Server
                '-d', domains,  # Domains to provision certs for
                '--eab-kid', account[0]['eab-key'],
                '--eab-hmac-key', account[0]['eab-hmac-key'],
                # Override directory paths so script doesn't have to be run as root
                '--config-dir', config.certbotpath + account_id + "/",
                '--work-dir', config.certbotpath,
                '--logs-dir', config.certbotpath, # desable Certbot logs
                '--cert-path', config.certpath,
                '--chain-path', config.chainpath,
                '--fullchain-path', config.fullchain,
                '--csr', config.csr,
                '--max-log-backups', 0,
                '--quiet'
            ])
            if os.path.exists(config.certpath):
                logging.info("CertbotProvider: Certificate retrieved by certbot")
                return True
            else:
                logging.error("CertbotProvider: No certificate retrieved by certbot")
                return False
        except Exception as ex:
            logging.error("CertbotProvider: Error while getting the certificate via certbot =  %s", ex)
            return False

    def get_cert_multiprocessing(self, account, domains, account_id):
        x = multiprocessing.Process(target=self.certbot_get_cert, args=(account, domains, account_id))
        x.start()
        x.join()
        x.terminate()
        return x

    def certbot_revoke_cert(self, account,account_id):
        try:
            certbot.main.main([
                'revoke',  # revoke cert
                '--standalone',
                '--noninteractive',  # Run in non-interactive mode
                '--agree-tos',  # Agree to the terms of service,
                '--email', account[0]['email'],  # Email
                '--server', account[0]['acme-endpoint'],  # Server
                '--eab-kid', account[0]['eab-key'],
                '--eab-hmac-key', account[0]['eab-hmac-key'],
                # Override directory paths so script doesn't have to be run as root
                '--config-dir', config.certbotpath + account_id + "/",
                '--work-dir', config.certbotpath,
                '--logs-dir', config.certbotpath, # desable Certbot logs
                '--cert-path', config.certpath,
                '--reason', 'unspecified',
                '--max-log-backups', 0,
                '--quiet'
            ])            
        
        except Exception as ex:
            if len(ex.args)>0 and ex.args[0]=='No match found for cert-path '+config.certpath+'!':
                logging.info("CertbotProvider: Certificate Revoked")
            else:
                logging.error("CertbotProvider: Error while revoke the certificate via certbot =  %s", ex)
                return False

    def revoke_cert_multiprocessing(self, account, account_id):
        x = multiprocessing.Process(target=self.certbot_revoke_cert, args=(account, account_id))
        x.start()
        x.join()
        x.terminate()
        return x