import AWSProvider
import logging
from configprovider import ConfigProvider
from dynamoprovider import DynamoProvider
import datetime
def xstr(s):
        if s is None:
            return ''
        return str(s)

def main(action, account_id=None, domains=None, arnreplace=None):    
    try:    
        logger = logging.getLogger()
        logger.setLevel(level=logging.INFO)
        config=ConfigProvider()
        # ***  To use local files configuration for dev and test purpose ***
        accounts = config.get_account_config(account_id)
        if accounts==None:
            logging.error("There is no such account in %s file",config.acmeaccountfilename)
            return None
        process=DynamoProvider()
        params='{"action": "'+xstr(action)+'","domains":"'+xstr(domains) +'","account_id":"'+xstr(account_id)+'","arnReplace":"'+xstr(arnreplace)+'"}'
        logging.info("Call params: %s",params)
        process_exist=process.checkprocess(params)
        if process_exist['Count']>0:    
            logging.info("Calling parameters already processing")
            return None
        process.saveprocess(params)
        try:   
            provider = AWSProvider.Provider(accounts, account_id, domains)
            provider.delete_cert_files()
            arn = None
            if action == 'enroll':                
                if account_id and domains:
                    account = accounts[account_id]
                    arn = provider.cert_enroll(account) 
                    return arn
                logging.info('Inform a valid account and domain(s) in order to enroll a certificate')
            cert_arn = arnreplace
            if action in ("renew", "forcerenew") and accounts:
                if cert_arn:         
                    provider.renew_certificate_by_arn(accounts, action, cert_arn)  
                else:
                    provider.cert_renew(action, accounts)

            if action in ("replace") and accounts:
                account = accounts[account_id]
                provider.replace_cert_with_sectigo(account, arnreplace)
            if action in ("revoke") and accounts:
                provider.revoke_cert(accounts, arnreplace)
        finally:
            process.endprocess(params)
    except Exception as e:
        logging.error("Error while starting SectigoAWSCM error = %s",e)

def get_params_from_api(event):
    try:
        action = account_id = domains = arn = None
        if "action" in event['params']['querystring'].keys():
            action = event['params']['querystring']['action']

        if "account" in event['params']['querystring'].keys():
            account_id = event['params']['querystring']['account']

        if "domains" in event['params']['querystring'].keys():
            domains = event['params']['querystring']['domains']

        if "arn" in event['params']['querystring'].keys():
            arn = event['params']['querystring']['arn']
        return action, account_id, domains, arn
    except Exception as e:
        logging.error("Error while getting params from  api error= %s",e)

def get_params_from_cli(event):
    try:
        action = account_id = domains = arn = None
        keys = event.keys()
        if "action" in keys:
            action = event['action']

        if "account" in (event.keys()):
            account_id = event['account']

        if "domains" in (event.keys()):
            domains = event['domains']

        if "arn" in (event.keys()):
            arn = event['arn']
        return action, account_id, domains, arn
    except Exception as e:
        logging.error("Error while getting params from  cli error= %s",e)

def main_handler(event, context):
    try:        
        action = account_id = domains = arn = None
        keys = event.keys()
        if "params" in keys:
            # API Gatway
            action, account_id, domains, arn = get_params_from_api(event)
        else:
            # AWS CLI
            action, account_id, domains, arn = get_params_from_cli(event)
        # validate parameters
        if action in ['enroll','renew','forcerenew','replace','revoke']:
            arn = main(action, account_id, domains, arn)
        else:
            logging.info("Invalid parameters %s", event)
        return arn
    except Exception as e:
        logging.error("Error while starting SectigoAWSCM %s",e)


# # >>  ########## Local test / Dev  ##############
# main function development/Test purpose
# Code used for local Test/ Development
 
if __name__ == '__main__':
    action = "enroll" #event['params']['querystring']['account']
    action = "revoke"
    account_id=None
    account_id = "rsa_4096" #['params']['querystring']['account']
    domains=None
    # domains = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')+".ccmqa.com" #['params']['querystring']['account']
    domains = '20211203194157231452.ccmqa.com'
    arn='arn:aws:acm:ca-central-1:011400459177:certificate/befaa9eb-226e-4e20-9cef-57efe6c51045'
    main(action, account_id, domains, arn)
#
# <<  ########## Local test / Dev  ##############

 