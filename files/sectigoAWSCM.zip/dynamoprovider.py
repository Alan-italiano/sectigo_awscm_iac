import logging
import boto3
from boto3.dynamodb.conditions import Key
from configprovider import ConfigProvider
import datetime

class DynamoProvider:
    def __init__(self) -> None:
        try:
            configprovider=ConfigProvider()
            self.DB=boto3.resource('dynamodb')
            self.table_name = configprovider.table_name
            self.table=self.DB.Table(self.table_name)
        except Exception as e:
             logging.error("Error while creating dynamo provider =  %s", e)

    def saveprocess(self,request_params):
        try:
            response=self.table.put_item(
                Item={
                    'RequestParameters':request_params,
                    'RequestStatus':'Processing',
                    'RequestDate':datetime.datetime.utcnow().isoformat()
                }
            ) 
            logging.info("Process saved to DynamoDB")
            return response
        except Exception as e:
             logging.error("Error while save item dynamo table=%s,error =  %s", self.table_name,e)

    def checkprocess(self,request_params):
        try:
            response = self.table.query(KeyConditionExpression=Key('RequestParameters').eq(request_params) & Key('RequestStatus').eq('Processing'))
            logging.info("Checking process from DynamoDB")
            return response
        except Exception as e:
             logging.error("Error while query dynamo table =  %s", e)

    def endprocess(self,request_params):
        try:
            response = self.table.delete_item(
                Key={
                    'RequestParameters':request_params,
                    'RequestStatus':'Processing'
                }
            )
            logging.info("Deleting process from DynamoDB")
            return response
        except Exception as e:
            logging.error("Error while deleting record dynamo table =  %s", e)