import const
import logging
import boto3
import yaml
import os

class ConfigProvider:       
    csr = const.certbotPath+ const.csr_name           
    allowduplicatedomains = const.AllowDuplicateDomains
    logger = logging.getLogger()
    logger.setLevel(level=logging.INFO)
    if os.getenv('s3_bucket_yaml'):
        logging.info("configprovider: Dynamically created s3 bucket found from env, s3_bucket_yaml=%s",os.getenv('s3_bucket_yaml')) 
        bucketname = os.getenv('s3_bucket_yaml')
    else:
        logging.info("configprovider: Got bucketname from const, s3_bucket_yaml=%s",const.bucket_name) 
        bucketname = const.bucket_name
    if os.getenv('lambda_name'):
        logging.info("Dynamically created lambda function name found from env, lambda_name=%s",os.getenv('lambda_name')) 
        lambda_name = os.getenv('lambda_name')
    else:
        logging.info("configprovider: Got lambda_name from const, lambda_name=%s",const.lambda_function_name) 
        lambda_name = const.lambda_function_name
    if os.getenv('table_name'):
        logging.info("Dynamically created Dynamo table_name found from env, table_name=%s",os.getenv('table_name')) 
        table_name = os.getenv('table_name')
    else:
        logging.info("configprovider: Got dynamo_table_name from const, table_name=%s",const.dynamo_table_name) 
        table_name = const.dynamo_table_name            
    acmeaccountfilename = const.acme_account_file
    issuer = const.Issuer
    certbotpath = const.certbotPath
    certpath = const.certbotPath+ const.cert_name
    keyfile=""
    chainpath = const.certbotPath+ const.chain_name
    fullchain = const.certbotPath+ const.full_chain_name
    logfile = const.certbotPath+ const.log_file_name
    
    def get_account_config(self,account_id=None):
        try:
            if const.debug_mode:
                with open(const.acme_account_file,'r') as yamlfile:
                    yaml_object = yaml.load(yamlfile, Loader=yaml.FullLoader)

            else:            
                s3_client = boto3.client('s3')
                bucket = self.bucketname
                key = self.acmeaccountfilename
                s3reponse = s3_client.get_object(Bucket=bucket, Key=key)
                yamlfile = s3reponse['Body']._raw_stream.data
                yaml_object = yaml.load(yamlfile, Loader=yaml.FullLoader)
            acme_accounts = yaml_object['accounts']
            if account_id:
                acme_accounts = {account_id: acme_accounts.get(account_id)}
            return acme_accounts                 
        except Exception as e:
            logging.error("configprovider: Error while reading the acccount file(bucketname=%s), error=%s", bucket,e)
    