import logging
import os
import boto3
from certbotprovider import CertbotProvider
from configprovider import ConfigProvider as configprovider
import const
import datetime
import ocsp
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import ec
from botocore.config import Config
import json


class Provider:
    def __init__(self, accounts=None, account_id=None, domains=None):
        try:            
            self.account_id = account_id
            self.domains = domains
            if account_id:
                self.account = accounts[account_id]    
        except TypeError as e:
            logging.error("awsprovider: Type Error while init provider error=  %s", e)
        except Exception as e:
            logging.error("awsprovider: Error while init provider error=  %s", e)

    def cert_enroll(self, account):
        try:
            cert = self.find_existing_cert_by_domains()
            certarn = None

            if cert and configprovider.allowduplicatedomains == False:
                certarn = cert["ResourceARN"]
                if cert['status'] == "GOOD" and cert["daystoexpire"] >= account[0]['RenewBeforeDays']:                    
                    logging.info("awsprovider: Certificate already exist = %s", cert["ResourceARN"])                    
                else:
                    logging.info("awsprovider: Certificate expired or revoked, for renew ARN = %s", cert["ResourceARN"])
                    # call renew_cert
                    self.renew_certificate_by_arn({self.account_id:account}, 'renew', certarn)  
            else:
                try:
                    if self.create_csr(self.account, self.domains):
                        crtbtprovider=CertbotProvider()
                        crtbtprovider.get_cert_multiprocessing(self.account,self.domains, self.account_id)
                        certarn = self.upload_cert_to_acm(self.account_id)
                    self.delete_cert_files()
                except Exception as e:
                    logging.error("awsprovider: Error - Enroll certificate, error=%s", e)
                finally:
                    self.delete_cert_files()
            return certarn
        except Exception as e:
            logging.error("awsprovider: Error while enroll the certificate error=  %s", e)
        finally:
            if certarn:
                logging.info("log cert retrieved %s ",certarn)
                
    def delete_if_exist(self,file_path):
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                logging.info("File deleted: %s",file_path)
        except PermissionError:
            logging.error('awsprovider: Permission Error while deleting certificate files')
        except Exception as e:
            logging.error('awsprovider: Error while deleting certificate files error=%s',e)

    def delete_cert_files(self):
            self.delete_if_exist(configprovider.csr)
            self.delete_if_exist(configprovider.certpath)
            self.delete_if_exist(configprovider.fullchain)
            self.delete_if_exist(configprovider.chainpath)
            self.delete_if_exist(configprovider.logfile)

    def renew_cert_for_account(self,cert,action,account): 
        try:       
            # renew cert that is expired or revoked
            shouldrenew = False
            if action == "forcerenew":
                # Force renew no matter the certificates condition
                shouldrenew = True
            else:
                if cert['status'] != "GOOD" or cert["daystoexpire"] <= account[0]['RenewBeforeDays']:
                    shouldrenew = True
                else:
                    if configprovider.allowduplicatedomains:
                        shouldrenew = True

            if shouldrenew:
                # invoke lambda renew by arn for every certificate due for renewal
                client = boto3.client('lambda')
                inputparams = {
                        "action"   : "forcerenew",
                        "arn": cert['metadata']['Certificate']['CertificateArn']
                    }
                client.invoke(
                    FunctionName =  configprovider.lambda_name,
                    InvocationType = 'Event',
                    Payload = json.dumps(inputparams)
                )                            
                logging.info("awsprovider: Invoked renew by ARN: %s", cert['metadata']['Certificate']['CertificateArn'])
            else:
                logging.info("awsprovider: Certificate not due to renew ARN: %s", cert['metadata']['Certificate']['CertificateArn'])
        except Exception as e:
            logging.info("awsprovider: Error happened renew cert for account: %s", e)

    def cert_renew(self, action,  accounts, domain=None):
        try:            
            # get account's ID
            all_accounts = list(accounts.keys())
            # loop over all account_ids
            for account_id in all_accounts:
                account = accounts.get(account_id)

                # get all the certificates for the account
                certs_account = self.list_sectigo_certificates(account_id)
                for cert in certs_account:
                    self.renew_cert_for_account(cert,action,account)
                # loop for each certificate in the account                
        except Exception as e:
            logging.error("awsprovider: Error while renewing a certificate error=%s",e)

    def create_key(self,account):
        try:
            key=None
            # validate the key type parameters
            if account[0]['KeyType'] not in ('RSA,ECDSA'):
                logging.error("awsprovider: Key type %s not valid, please choose RSA or ECDSA", account[0]['KeyType'])
                return False        
            if account[0]['KeyType'] == "RSA":
                if str(account[0]['KeySize']) in (const.RSA_allwed_key_size):
                    key = rsa.generate_private_key(
                        public_exponent=65537,
                        key_size=account[0]['KeySize'])
                else:
                    logging.info("awsprovider: RSA Key size not supported. Supported KeySizes: %s",const.RSA_allwed_key_size)

            if account[0]['KeyType'] == "ECDSA":
                if const.ecdsa_keys.get(account[0]['KeySize']):
                    key = ec.generate_private_key(
                        const.ecdsa_keys.get(account[0]['KeySize'])
                    )
                else:
                    logging.info("awsprovider: ECDSA Key size not supported. Supported KeySizes: %s ",const.ECDSA_allwed_key_size)
            return key
        except Exception as e:
            logging.error("awsprovider: Private key not created error=%s",e)
            return None

    def create_csr(self, account, domains):
        try:           
            key=self.create_key(account)
            if key:
                configprovider.keyfile=key.private_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PrivateFormat.PKCS8,
                        encryption_algorithm=serialization.NoEncryption(),
                    )

                list_domains = domains.replace(' ','').split(',')

                subjectaltnames = []
                for domain in list_domains:
                    subjectaltnames.append(x509.DNSName(domain))

                # Generate a CSR
                csr = x509.CertificateSigningRequestBuilder()
                if account[0]['email']:                   
                    cert_details = [     
                        x509.NameAttribute(NameOID.EMAIL_ADDRESS, account[0]['email']),
                        x509.NameAttribute(NameOID.COMMON_NAME, list_domains[0])]
                else:
                    cert_details = [x509.NameAttribute(NameOID.COMMON_NAME, list_domains[0])]


                csr = csr.subject_name(x509.Name(cert_details))

                csr = csr.add_extension(
                        x509.SubjectAlternativeName(subjectaltnames),
                        critical=False,
                    )

                csr = csr.sign(key, hashes.SHA256())

                with open(configprovider.csr, "wb") as f:
                    f.write(csr.public_bytes(serialization.Encoding.PEM))

                if os.path.exists(configprovider.csr) :                            
                    logging.info("awsprovider: CSR is created")
                    return True
            else:
                logging.error("awsprovider: Private key not created")
                return False
        except Exception as err: print(f"Unexpected {err=}, {type(err)=}")


    def find_existing_cert_by_domains(self):
        try:
            # check if already exist a certificate for the domains
            domains = frozenset(self.domains.split(','))
            certficates = self.list_sectigo_certificates()
            cert = None
            client = boto3.client('acm')
            for item in certficates:
                sans = frozenset(item['metadata']['Certificate']['SubjectAlternativeNames'])
                if domains == sans:
                    item["cert"] = client.get_certificate(CertificateArn=item['ResourceARN'])
                    item["daystoexpire"] = ((certficates[0]["metadata"]["Certificate"]["NotAfter"]).replace(
                         tzinfo=None) - datetime.datetime.now()).days
                    item["status"] = ocsp.get_ocsp_status_of_cert(item["cert"]["Certificate"])
                    cert = item
                    break
            return cert
        except Exception as e:
            logging.error("awsprovider: Error find existing certificate by domain=  %s",e) 

    def upload_cert_to_acm(self, account_id, certificate_arn=None):
        try:
            config = Config(
            retries = {
                'max_attempts': 20,
                'mode': 'standard'
            }
            )
            client = boto3.client('acm',config=config)

            if not os.path.exists(configprovider.certpath):
               logging.error("awsprovider: File not exist =  %s", configprovider.certpath)                         
            if not os.path.exists(configprovider.chainpath):
               logging.error("awsprovider: File not exist =  %s", configprovider.chainpath) 
            bcert = open(configprovider.certpath, 'rb').read()
            bkey = configprovider.keyfile
            bchain = open(configprovider.chainpath, 'rb').read()

            if certificate_arn:
                acm_response = client.import_certificate(
                    CertificateArn=certificate_arn,
                    Certificate=bcert,
                    PrivateKey=bkey,
                    CertificateChain=bchain
                )
                if acm_response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    logging.info("awsprovider: Certificate updated ARN= %s ", certificate_arn)

            else:
                # import a certificate for the first time
                cert_name = const.cert_prefix + "-" +  datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
                acm_response = client.import_certificate(
                    Certificate=bcert,
                    PrivateKey=bkey,
                    CertificateChain=bchain,
                    Tags=[
                            {
                                'Key': "CertIssuer",
                                'Value': configprovider.issuer
                            },
                            {
                                'Key': "SectigoID",
                                'Value': account_id
                            },
                            {
                                'Key': "Name",
                                'Value': cert_name
                            }
                        ]
                )
                if acm_response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    logging.info("awsprovider: Certificate uploaded ARN:%s ", acm_response['CertificateArn'])
            return None if certificate_arn else acm_response['CertificateArn']
        except Exception as e:
            logging.error("awsprovider: Error while upload the certificate to acm=  %s", e)
            
    def renew_certificate_by_arn(self, accounts, action, arn=None):
        try:
            # 1 - get the Certicate details "demo2" - describe_certificate(
            #cert_name =  const.cert_prefix + "-" + datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
            client = boto3.client('acm')
            cert = client.describe_certificate(CertificateArn=arn)
            domains = cert['Certificate']['SubjectAlternativeNames'][0]
            # 2 - get tags ()  list_tags_for_certificate
            tags = client.list_tags_for_certificate(CertificateArn=arn)
            # 3 - get account from tags (check if demo2 still exist)   
            account_id=[x['Value'] for x in tags['Tags'] if x['Key'] == 'SectigoID'][0]
            account=accounts[account_id]
            if account:
                # 4 - Get a new certificate - certbot_get_cert
                if self.create_csr(account, domains):
                    crtbtprovider=CertbotProvider()
                    crtbtprovider.get_cert_multiprocessing(account, domains, account_id)
                # 6 Uplod cert - upload_cert_to_acm
                certarn = self.upload_cert_to_acm(account_id, arn)
                self.delete_cert_files()
                logging.info("awsprovider: cert renewed certArn: %s",certarn)  
                return certarn
            else:
                logging.info("awsprovider: Account %s not found",account_id)      
        except Exception as e:
            logging.info("awsprovider: Error while renewing certificate by arn, error=%s",e)

    def list_sectigo_certificates(self, account_id=None):
        try:
            if account_id:
                self.account_id = account_id

            client = boto3.client('resourcegroupstaggingapi')
            tagfilter = [{'Key': "CertIssuer",'Values': [configprovider.issuer]}]

            if self.account_id:
                tagfilter.append({'Key': "SectigoID", 'Values': [self.account_id]})

            certificates = client.get_resources(
              ResourcesPerPage=50,
              TagFilters=tagfilter
            )

            certs = certificates['ResourceTagMappingList']
            # check if still have certificates to be listed by the token
            while certificates["PaginationToken"]:
                certificates = client.get_resources(
                  PaginationToken=certificates["PaginationToken"],
                  ResourcesPerPage=50,
                  TagFilters=[
                    {
                      'Key': "CertIssuer",
                      'Values': [configprovider.issuer]
                    }]
                )
                certs = certs + certificates['ResourceTagMappingList']

            client = boto3.client('acm')
            for item in certs:
                item['metadata'] = client.describe_certificate(CertificateArn=item['ResourceARN'])
                if account_id:
                    item["cert"] = client.get_certificate(CertificateArn=item['ResourceARN'])
                    item["daystoexpire"] = ((certs[0]["metadata"]["Certificate"]["NotAfter"]).replace(
                        tzinfo=None) - datetime.datetime.now()).days
                    item["status"] = ocsp.get_ocsp_status_of_cert(item["cert"]["Certificate"])
            return certs
        except Exception as e:
            logging.info("awsprovider: Error while validating certificate against OCSP, error=%s",e)


    def replace_cert_with_sectigo(self, account, arnreplace):
        # 1 - add tags to the certificate existing certificate
        # 2 - get certificate details
        # 3 - Create a new certificate
        # 4 - Upload the new certificate

        # 1 - add tags to the certificate
        try:
            cert_name =  const.cert_prefix + "-" + datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
            client = boto3.client('acm')
            certarn=None
            client.add_tags_to_certificate(
                CertificateArn=arnreplace,
                Tags=[
                    {
                        'Key': "CertIssuer",
                        'Value': configprovider.issuer
                    },
                    {
                        'Key': "SectigoID",
                        'Value': self.account_id
                    },
                    {
                        'Key': "Name",
                        'Value': cert_name
                    }
                ]
            )

            # 2 - get certificate details
            client = boto3.client('acm')
            cert = client.describe_certificate(CertificateArn=arnreplace)
            domains = cert['Certificate']['SubjectAlternativeNames'][0]

            self.create_csr(account, domains)
            crtbtprovider=CertbotProvider()
            crtbtprovider.get_cert_multiprocessing(account, domains, self.account_id)
            certarn = self.upload_cert_to_acm(self.account_id, arnreplace)
            self.delete_cert_files()
            return certarn
        except Exception as e:
            logging.error("awsprovider: Error while replace the certificate via certbot error=  %s", e)
            return False

    def revoke_cert(self,accounts,arnreplace):
        try:
            client = boto3.client('acm')
            cert = client.get_certificate(CertificateArn=arnreplace)
            tags = client.list_tags_for_certificate(CertificateArn=arnreplace)
            account_id=[x['Value'] for x in tags['Tags'] if x['Key'] == 'SectigoID'][0]
            account=accounts[account_id]
            with open(configprovider.certpath, "w") as f:
                f.write(cert['Certificate'])
            if os.path.exists(configprovider.csr) :                            
                logging.info("awsprovider: Got Cert from AWS Cert Manager and saved to local")
            crtbtprovider=CertbotProvider()
            crtbtprovider.revoke_cert_multiprocessing(account,account_id)
            self.delete_cert_files()
        except client.exceptions.ResourceNotFoundException:
            logging.error("awsprovider:couldnt find cert by this arn=  %s", arnreplace)
        except Exception as e:
            print(e.__class__)
            logging.error("awsprovider: Error while revoke the certificate via certbot error=  %s", e)
            return False
