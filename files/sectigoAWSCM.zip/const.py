from cryptography.hazmat.primitives.asymmetric import ec
#Sectigo constantes
# ******************************************************
#   Do not change the contants after start using the system.
# ******************************************************
# tags name used to name the certificate on AWS
dynamo_table_name="sectigoAWSCM"
cert_prefix="Cert"
bucket_name="sectigo-awscm-ca"
lambda_function_name="SectigoAWSCM-default"
acme_account_file="acme_accounts.yaml"
RSA_allwed_key_size=["2048","4096"]
ECDSA_allwed_key_size=["256","384","521"]
csr_name="csr.pem"
cert_name="cert.pem"
full_chain_name="full_chain.pem"
chain_name="chain.pem"
key_name="key.pem"
log_file_name="letsencrypt.log"
ecdsa_keys = {384: ec.SECP384R1(), 256: ec.SECP256R1(), 521: ec.SECP521R1}
certbotPath = "/tmp/"
Issuer = "Sectigo"
AllowDuplicateDomains = False
debug_mode=False


